package com.mycompany.sevasethu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
