import '/flutter_flow/flutter_flow_util.dart';
import 'open_grievance_widget.dart' show OpenGrievanceWidget;
import 'package:flutter/material.dart';

class OpenGrievanceModel extends FlutterFlowModel<OpenGrievanceWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
