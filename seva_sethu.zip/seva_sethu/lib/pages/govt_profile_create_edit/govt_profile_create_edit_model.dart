import '/flutter_flow/flutter_flow_util.dart';
import 'govt_profile_create_edit_widget.dart' show GovtProfileCreateEditWidget;
import 'package:flutter/material.dart';

class GovtProfileCreateEditModel
    extends FlutterFlowModel<GovtProfileCreateEditWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for yourdept widget.
  FocusNode? yourdeptFocusNode;
  TextEditingController? yourdeptController;
  String? Function(BuildContext, String?)? yourdeptControllerValidator;
  // State field(s) for city widget.
  FocusNode? cityFocusNode;
  TextEditingController? cityController;
  String? Function(BuildContext, String?)? cityControllerValidator;
  // State field(s) for myBio widget.
  FocusNode? myBioFocusNode;
  TextEditingController? myBioController;
  String? Function(BuildContext, String?)? myBioControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    yourdeptFocusNode?.dispose();
    yourdeptController?.dispose();

    cityFocusNode?.dispose();
    cityController?.dispose();

    myBioFocusNode?.dispose();
    myBioController?.dispose();
  }
}
