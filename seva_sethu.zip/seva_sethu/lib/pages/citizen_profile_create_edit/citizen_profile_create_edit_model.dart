import '/flutter_flow/flutter_flow_util.dart';
import 'citizen_profile_create_edit_widget.dart'
    show CitizenProfileCreateEditWidget;
import 'package:flutter/material.dart';

class CitizenProfileCreateEditModel
    extends FlutterFlowModel<CitizenProfileCreateEditWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // State field(s) for yourFirstName widget.
  FocusNode? yourFirstNameFocusNode;
  TextEditingController? yourFirstNameController;
  String? Function(BuildContext, String?)? yourFirstNameControllerValidator;
  // State field(s) for yourLastName widget.
  FocusNode? yourLastNameFocusNode;
  TextEditingController? yourLastNameController;
  String? Function(BuildContext, String?)? yourLastNameControllerValidator;
  // State field(s) for city widget.
  FocusNode? cityFocusNode;
  TextEditingController? cityController;
  String? Function(BuildContext, String?)? cityControllerValidator;
  // State field(s) for pNo widget.
  FocusNode? pNoFocusNode;
  TextEditingController? pNoController;
  String? Function(BuildContext, String?)? pNoControllerValidator;
  DateTime? datePicked;
  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    yourFirstNameFocusNode?.dispose();
    yourFirstNameController?.dispose();

    yourLastNameFocusNode?.dispose();
    yourLastNameController?.dispose();

    cityFocusNode?.dispose();
    cityController?.dispose();

    pNoFocusNode?.dispose();
    pNoController?.dispose();
  }
}
