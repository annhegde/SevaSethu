import '../database.dart';

class UsersTable extends SupabaseTable<UsersRow> {
  @override
  String get tableName => 'users';

  @override
  UsersRow createRow(Map<String, dynamic> data) => UsersRow(data);
}

class UsersRow extends SupabaseDataRow {
  UsersRow(super.data);

  @override
  SupabaseTable get table => UsersTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String? get firstName => getField<String>('firstName');
  set firstName(String? value) => setField<String>('firstName', value);

  String? get lastName => getField<String>('lastName');
  set lastName(String? value) => setField<String>('lastName', value);

  String? get pNo => getField<String>('pNo');
  set pNo(String? value) => setField<String>('pNo', value);

  String? get password => getField<String>('password');
  set password(String? value) => setField<String>('password', value);

  DateTime? get dob => getField<DateTime>('dob');
  set dob(DateTime? value) => setField<DateTime>('dob', value);

  String? get area => getField<String>('area');
  set area(String? value) => setField<String>('area', value);

  int? get popularity => getField<int>('popularity');
  set popularity(int? value) => setField<int>('popularity', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  String? get loc => getField<String>('loc');
  set loc(String? value) => setField<String>('loc', value);
}
