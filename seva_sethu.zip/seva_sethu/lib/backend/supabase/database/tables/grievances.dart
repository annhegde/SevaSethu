import '../database.dart';

class GrievancesTable extends SupabaseTable<GrievancesRow> {
  @override
  String get tableName => 'grievances';

  @override
  GrievancesRow createRow(Map<String, dynamic> data) => GrievancesRow(data);
}

class GrievancesRow extends SupabaseDataRow {
  GrievancesRow(super.data);

  @override
  SupabaseTable get table => GrievancesTable();

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get title => getField<String>('title');
  set title(String? value) => setField<String>('title', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get location => getField<String>('location');
  set location(String? value) => setField<String>('location', value);

  int? get upvotes => getField<int>('upvotes');
  set upvotes(int? value) => setField<int>('upvotes', value);

  String get createdBy => getField<String>('createdBy')!;
  set createdBy(String value) => setField<String>('createdBy', value);

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);
}
