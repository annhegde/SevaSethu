import '../database.dart';

class ResolutionTable extends SupabaseTable<ResolutionRow> {
  @override
  String get tableName => 'resolution';

  @override
  ResolutionRow createRow(Map<String, dynamic> data) => ResolutionRow(data);
}

class ResolutionRow extends SupabaseDataRow {
  ResolutionRow(super.data);

  @override
  SupabaseTable get table => ResolutionTable();

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  bool? get govtSays => getField<bool>('govtSays');
  set govtSays(bool? value) => setField<bool>('govtSays', value);

  bool? get peopleSays => getField<bool>('peopleSays');
  set peopleSays(bool? value) => setField<bool>('peopleSays', value);

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);
}
